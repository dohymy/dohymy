// 자료형 변환
console.log(123, String(123)); // 123은 숫자인데 string으로 문자로 변환
console.log(Number('101'),Number(true),Number(false),Number('hello'));
// Number로 '101', true, false를 숫자로 변환시킴, NaN은 숫자자료지만 숫자가 아니라는 뜻
console.log(Boolean(0),Boolean(0.0),Boolean(''),Boolean(undefined),
Boolean(NaN),Boolean(null));
// 위 값들은 Boolean에서 false로 나오는 값
console.log(Boolean(0.00001),Boolean(' '),Boolean({ }));
// true로 나오는 값 (공백이 아닌 스페이스바를 입력해도)

// 자동변환
// boolean -> number -> string
console.log('bool'+true, 'integer'+123, 123+true);
// 각 booltrue, integer123, 124가 됨.
// -, *, /인 경우에는 string -> number로 바뀜.
console.log('52' - 273, '8'*8, '4'/2);
// 문자가 숫자로 변환되어 계산됨.

// 일치 연산자 : 두 개의 값이 똑같은지
// 1) 변환된 값이 같으면 같다.
console.log(52 == 52.0, 52 == '52'); // true, true
console.log(true==1, false==0.0); // true, true
// 2) 변환된 값과 자료형이 일치하면 같다
console.log(52 === 52.0, 52 === '52'); // true, false
console.log(true===1, false===0.0); // false, false