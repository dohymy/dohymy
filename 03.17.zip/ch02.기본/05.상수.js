// Constant (상수, 값이 변하지 않는 수)
const Constant = 'Hello';
console.log(Constant);
// Constant += 'World'; : 런타임 에러 발생
const obj = {x: 1, y: 2};
obj.x = 10;
obj.y = 20;
console.log(obj); // const로 값을 정했지만 값이 변함. 참조형 변수