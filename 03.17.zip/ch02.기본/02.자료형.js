// 자바스크립트의 자료형
// 1. Number
console.log(5 / 2);
console.log(5 % 2); // modulo : 나머지 계산
// console.log(2 ** 10); // 2의 10승
console.log(1.3e10);

//2. 문자열(string)
// console.log("She said "I love you." "); ""가 중첩 됐을 때
console.log('She said "I love you." ');
console.log("She said\"I love you.'\ ");
console.log('Back slash(\\) 기호를 사용할 때는 \\ 두개를 쓰면 됩니다.');
let hello = '안녕하세요?';
console.log(hello[0],hello[5]);
// template literal(`)
let a=2, b=3;
console.log(a, '더하기', b, '을 한 결과는', (2 + 3) ,'입니다.');
console.log(`2 더하기 3을 한 결과는`, 2 + 3, `입니다`);
console.log(`2 더하기 3을 한 결과는 ${2 + 3} 입니다.`);
console.log(`${a} 더하기 ${b}을 한 결과는 ${2+3}입니다.`);
console.log(`She said "I love you." `);
console.log(`올해는 ${new Date().getFullYear()}년입니다.`);

// 3. 논리형(Bool)
console.log(typeof(true), typeof(false)); // boolean
console.log(2 == 2.0, 5 >= 4, `가나다` > `마바사`);
//문자열에도 순서가 있다. 사전 순서대로 크다 (가나다라...=1234...)
let x = 10;
console.log(x > 8 || x < -3); // x > 8 또는 x < -3
console.log(x >= 0 && x <= 5); // 0 <= x <= 5 |
console.log(true > 10); // true가 1로 자동변환되어 비교가 됨.
