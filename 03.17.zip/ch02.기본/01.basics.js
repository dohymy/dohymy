let a = "자바" + "스크립트" ;
a = 'Hello World!!'+ a ;
console.log(a) ;