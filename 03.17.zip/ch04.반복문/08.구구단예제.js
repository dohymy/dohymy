let N = 8;
for (let i = 1; i <= 9; i++){
    multi = N*i;
    console.log(`${N}*${i}=${multi}`);
}

