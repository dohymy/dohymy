// 배열에서 최대 최소값 찾기
let numbers = [13,57,25,48,7,83,79,61,22,39]

// 최대값 찾기
let maxVal = 0; // 가장 작은 값을 준다.
for (let i = 0; i < numbers.length; i++){
    if (maxVal < numbers[i])
        maxVal = numbers[i];
}
console.log(maxVal);

// 최소값 찾기
let minVal = 1000; // 가장 큰 값을 준다.
for (let number of numbers){
    if (minVal > number)
        minVal = number;
}
console.log(minVal);

// 동시에 찾기
// maxVal = 0, minVal = 1000;
maxVal = numbers[0], minVal = numbers[0]; // 값을 알 수 없을땐 이렇게

for (let number of numbers){
    if (maxVal < number)
        maxVal = number;
    if (minVal > number)
        minVal = number;
}
console.log(`최소값 : ${minVal}, 최대값 : ${maxVal}`);