//배열
let arr = [52, true, '감', 'banana', 250];
console.log(arr);
console.log(typeof arr);
console.log(arr.length);
console.log(arr[0], arr[2], arr[arr.length - 1]);

//while 반복문
let i = 0; // i는 index의 의미
while (i < arr.length) {
    console.log(`index=${i}, value=${arr[i]}`);
    i++; // while 조건을 변화시키는 값이 무조건 나와야 함.
}

//for 반복문 ** 매우 중요, 구조 암기 필수
for (let i=0; i < arr.length; i++){ 
    console.log(`index=${i}, value=${arr[i]}`);
}

// enhanced for-loop 
console.log('Enhanced for-loop');
for (let item of arr)
    console.log(item); // index와 value를 출력하지않고 내용만 출력할 때.
