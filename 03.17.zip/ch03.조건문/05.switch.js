// switch - multiple select

let score = 84;
let scoreDigit = parseInt(score / 10); // parseInt : 정수로 바꿔줌
// Math.floor(score / 10); // 10으로 나눈 몫
let grade;

switch(scoreDigit){
    case 10:
    case 9:
        grade = 'A';
        break; // 조건에 맞으면 멈춰라. 조건에 맞는데 다음 식을 실행하지 않도록.
    case 8:
        grade = 'B';
        break;
    case 7:
        grade = 'C';
        break;
    case 6:
        grade = 'D';
        break;
    default: // 위 조건 외의 값
        grade = 'F';
}

console.log(`성적: ${score}, 학점: ${grade}`);