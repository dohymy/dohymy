// 홀수/짝수
let num = Math.ceil(Math.random()*100);

if (num % 2 == 1){
    console.log(`${num}은/는 홀수입니다.`);
}
if (num % 2== 0){
    console.log(`${num}은/는 짝수입니다.`);
}

// math.random : 랜덤한 숫자 생성, 정수는 *100을 추가
// math.ceil() : 올림, math.floor : 내림