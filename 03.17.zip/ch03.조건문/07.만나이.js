// 생일 - 오늘 현재 만나이 계산
const bYear = 2000, bMonth = 3, bDay = 15;
const today = new Date();
const tYear = today.getFullYear();
const tMonth = today.getMonth() + 1 ;
const tDay = today.getDate();
console.log(tYear, tMonth, tDay);

let age = tYear - bYear;

if (bMonth - tMonth >= 0 && bDay - tDay > 0)
{
    console.log(`만${age-1}세`);
}
else {
    console.log(`만${age}세`);
};